/* tslint:disable */
require("./Tile.module.css");
const styles = {
  tile: 'tile_51ac5ca3',
  container: 'container_51ac5ca3',
  row: 'row_51ac5ca3',
  column: 'column_51ac5ca3',
  'ms-Grid': 'ms-Grid_51ac5ca3',
  title: 'title_51ac5ca3',
  subTitle: 'subTitle_51ac5ca3',
  description: 'description_51ac5ca3',
  button: 'button_51ac5ca3',
  label: 'label_51ac5ca3'
};

export default styles;
/* tslint:enable */