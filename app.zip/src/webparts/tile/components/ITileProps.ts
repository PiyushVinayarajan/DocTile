export interface ITileProps {
  description: string;
}
