declare interface ITileWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'TileWebPartStrings' {
  const strings: ITileWebPartStrings;
  export = strings;
}
