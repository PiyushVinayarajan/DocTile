export interface ITileProps {
    description: string;
}
//# sourceMappingURL=ITileProps.d.ts.map