import * as React from 'react';
import { ITileProps } from './ITileProps';
export default class Tile extends React.Component<ITileProps, any> {
    constructor(props: any);
    componentDidMount(): void;
    getImage(input: any): string;
    render(): React.ReactElement<ITileProps>;
}
//# sourceMappingURL=Tile.d.ts.map